//var oplist=["rambio.html","bravabio.html","floresbio.html","zerobio.html","nokkbio.html","ianabio.html","dokkabio.html","sledgebio.html","thatcherbio.html","lionbio.html"];
//ram brava flores zero nokk iana dokka sledge thatcher lion 
//tubarao pulse kaid bandit mozzie ela azami warden aruni castle
//stnd, qp, rk

var filt = ["kvikk","sztend","tryhard"];

function swiccs()
{
    document.addEventListener('click',function(kattint){
        kattinta = kattint.target.id;
        var ezmi = document.getElementById(kattinta);
        var valami = ezmi.id;
        var url = valami+".html";
    
        window.location.href = url;
        
    });
}


/*
function mapfilter()
{
    document.addEventListener('click',function(nem){
        kattints = nem.target.id;
        var ezmi = document.getElementById(kattints);
        var valami = ezmi.id;
        valami.item.style.display = 'none';
        
    });
}
*/


/*
    for (var i = 0; i< elements.length; i++)
    {
        var id = elements[i].id;
        alert('Az ' + (i+1) + '.elem ID-je: ' + id);
    }*/
/*function mapfilter()
{
    
    document.addEventListener('click',function(igen)
    {
        var elements = document.getElementById(igen.target.id)
        alert(elements);
        if(igen.target.id = elements)
        {
           elements.style.display = 'none'; 
        }
        
        

    });
}*/
